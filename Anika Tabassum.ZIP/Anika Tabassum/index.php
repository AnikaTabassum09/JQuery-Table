<?php

 $connect = mysqli_connect("localhost", "root", "system" , "project_db");
?>

<!DOCTYPE html>
<html>
 <head>
  <title>Employee Info</title>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
 </head>
 <body>
  <br />
  <div class="container">
   <h3 align="center">Employee Information</h3>
   <br />
   <h4 align="center">Enter Employee Details</h4>
   <br />
   <form method="post" id="insert_form">
    <div class="table-repsonsive">
     <span id="error"></span>
     <table class="table table-bordered" id="employee_table">
      <tr>
       <th>Employee Name</th>
       <th>Employee Email</th>
       <th>Mobile Number</th>
		<th>Select Division</th>
   
      
     <th><button type="button" name="add" class="btn btn-success btn-sm add"><span class="glyphicon glyphicon-plus"></span></button></th>
      </tr>
     </table>
     <div align="center">
      <input type="submit" name="submit" class="btn btn-info" value="Insert" /> 
     </div>
    </div>
   </form>
  </div>
 </body>
</html>

<script>
$(document).ready(function(){
 
 $(document).on('click', '.add', function(){
  var html = '';
  html += '<tr>';
  html += '<td><input type="text" name="name[]" class="form-control name" /></td>';
  html += '<td><input type="text" name="email" class="form-control email" /></td>';
  html += '<td><input type="text" name="mobile" class="form-control mobile" /></td>';
   html += '<td><select name="item_unit[]" class="form-control item_unit"><option value="">Select Division</option><option value="dhaka">Dhaka</option><option value="barishal">Barishal</option><option value="chittagong">Chittagong</option><option value="khulna">Khulna</option><option value="Mymensingh">Mymensingh</option><option value="rajshahi">Rajshahi</option><option value="rangpur">Rangpur</option><option value="sylhet">Sylhet</option></select></td>';
  html += '<td><button type="button" name="remove" class="btn btn-danger btn-sm remove"><span class="glyphicon glyphicon-minus"></span></button></td></tr>';
  $('#employee_table').append(html);
 });
 
 $(document).on('click', '.remove', function(){
  $(this).closest('tr').remove();
 });
 
 $('#insert_form').on('submit', function(event){
  event.preventDefault();
  var error = '';
  $('.name').each(function(){
   var count = 1;
   if($(this).val() == '')
   {
    error += "<p>Enter Employee Name at "+count+" Row</p>";
    return false;
   }
   count = count + 1;
  });
  
  $('.email').each(function(){
   var count = 1;
   if($(this).val() == '')
   {
    error += "<p>Enter Email at "+count+" Row</p>";
    return false;
   }
   count = count + 1;
  });

  $('.mobile').each(function(){
   var count = 1;
   if($(this).val() == '')
   {
    error += "<p>Enter Mobile at "+count+" Row</p>";
    return false;
   }
   count = count + 1;
  });
  
  /*$('.division').each(function(){
   var count = 1;
   if($(this).val() == '')
   {
    error += "<p>Select Division at "+count+" Row</p>";
    return false;
   }
   count = count + 1;
  });*/

   $('.item_unit').each(function(){
   var count = 1;
   if($(this).val() == '')
   {
    error += "<p>Select Unit at "+count+" Row</p>";
    return false;
   }
   count = count + 1;
  });


  var form_data = $(this).serialize();
  if(error == '')
  {
   $.ajax({
    url:"insert.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
     if(data == 'ok')
     {
      $('#employee_table').find("tr:gt(0)").remove();
      $('#error').html('<div class="alert alert-success">Employee Details Saved</div>');
     }
    }
   });
  }
  else
  {
   $('#error').html('<div class="alert alert-danger">'+error+'</div>');
  }
 });
 
});
</script>

