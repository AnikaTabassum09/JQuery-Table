<?php
//insert.php;

if(isset($_POST["name"]))
{
$connect = mysqli_connect("localhost", "root", "system" , "project_db");
 $id = uniqid();
 for($count = 0; $count < count($_POST["name"]); $count++)
 {  
  $query = "INSERT INTO employee 
  (id, name, email, mobile, division) 
  VALUES (:id, :name, :email, :mobile, :division)
  ";
  $statement = $connect->prepare($query);
  $statement->execute(
   array(
    ':id'   => $id,
    ':name'  => $_POST["name"][$count], 
    ':email' => $_POST["email"][$count],
    ':mobile' => $_POST["mobile"][$count],  
    ':division'  => $_POST["division"][$count]
   )
  );
 }
 $result = $statement->fetchAll();
 if(isset($result))
 {
  echo 'ok';
 }
}
?>
